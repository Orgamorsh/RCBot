//Constants, variables, etc.
const Discord = require('discord.js');
const readline = require('readline');
const bot = new Discord.Client();
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
var ActiveServer = 'null';
var ActiveUser = 'null';
function wait(ms){
  var start = new Date().getTime();
  var end = start;
  while(end < start + ms) {
    end = new Date().getTime();
 }
}

//Bot start
bot.login('Put login token Here')

bot.on('ready', () =>{
    console.log('Bot online.')
});

//Console commands
rl.on('line', (line) => {

    if(line === '/quit') {
      bot.user.setStatus('invisible')
      rl.write('Quitting')
      wait(2000)
      process.exit()
    }
    
    else if(line === '/status') {
        
      rl.question('Set status.', (answerss) => {
        bot.user.setStatus(answerss)
      })
  
    }
  
    else if(line === '/game') {
        
      rl.question('Set game.', (answerssss) => {
        bot.user.setActivity(answerssss)
      })
  
    }
  
    else if(line === '/stream') {
        
      rl.question('Set stream.', (answerc) => {
        bot.user.setActivity(answerc, {type: 'STREAMING'})
      })
  
    }
  
    else if(line === '/watch') {
        
      rl.question('Set watch status.', (answerd) => {
        bot.user.setActivity(answerd, {type: 'WATCHING'})
      })
  
    }
  
    else if(line === '/listen') {
        
      rl.question('Set listen status.', (answere) => {
        bot.user.setActivity(answere, {type: 'LISTENING'})
      })
  
    }
  
    else if(line === '/name') {
        
      rl.question('Set name.', (answersa) => {
        bot.user.setUsername(answersa)
      })
  
    }
  
    else if(line === '/channel'){
   
      rl.question('Enter channel id.', (answer) => {
        ActiveServer = answer,
        console.log('Channel is now', ActiveServer)
      })
    }
    
    else if(line === '/user'){
   
      rl.question('Enter user id.', (answeuwu) => {
        ActiveUser = answeuwu,
        console.log('Selected user is now', ActiveUser)
      })
    }
    
    else if(line === '/currentchannel'){
      console.log(ActiveServer)
    }
  
    else if(line === '/currentuser'){
      console.log(ActiveUser)
    }
  
    else if(line === '/dm'){
      if (ActiveUser === 'null'){
          console.log('ERROR: No user ID found. Use /user to set an ID.')
      }else if (ActiveUser === ''){
        console.log('ERROR: No user ID found. Use /user to set an ID.')
      }else
      rl.question('Enter message.', (dmmessage) => {
        bot.users.get(ActiveUser).send(dmmessage)
      })
    }
  
    else{
      if (ActiveServer === 'null'){
        return
      
      }else if (ActiveServer === ''){
        return
        
      }else {
        bot.channels.get(ActiveServer).send(line)
      }
    }
  
  });

//Log Messages for DMs
bot.on('message', message => {

    if(message.channel.type === "dm") console.log(`[DM from ${message.author.username}] - ${message.content}`);
  
  })
  
  //Log Messages for active channel
  bot.on('message', message => {
  
    if(message.channel.id === ActiveServer) console.log(`[${message.channel.name}, ${message.author.username}] - ${message.content}`);
  
  })